import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmlpoyeeDetailComponent } from './emlpoyee-detail.component';

describe('EmlpoyeeDetailComponent', () => {
  let component: EmlpoyeeDetailComponent;
  let fixture: ComponentFixture<EmlpoyeeDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmlpoyeeDetailComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmlpoyeeDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
