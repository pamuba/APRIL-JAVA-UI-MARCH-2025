import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-emlpoyee-detail',
  templateUrl: './emlpoyee-detail.component.html',
  styleUrl: './emlpoyee-detail.component.css'
})
export class EmlpoyeeDetailComponent {
  constructor(private empService:EmployeeService){}
  
    employees:Employee[] = []
  
    ngOnInit(){
      this.empService.getEmployees()
        .subscribe(data => this.employees = data);
    }
}
