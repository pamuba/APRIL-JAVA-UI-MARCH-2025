import { Component } from '@angular/core';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-departmentdetail',
  templateUrl: './departmentdetail.component.html',
  styleUrl: './departmentdetail.component.css'
})
export class DepartmentdetailComponent {
 constructor(private activeRoute:ActivatedRoute, private router:Router){}
 departmentId:number = 0
 ngOnInit(){
  // let id =  this.activeRoute.snapshot.paramMap.get('id')
  //this.departmentId = Number(id);

  this.activeRoute.paramMap.subscribe(params => {
    let id = params.get('id')
    this.departmentId = Number(id)
  })
 }
 goPrevious(){
  let previousId = (this.departmentId -1)
  this.router.navigate(['/departments', previousId])
 }

 goNext(){
  let nextId = this.departmentId + 1
  this.router.navigate(['/departments', nextId])
 }
}
