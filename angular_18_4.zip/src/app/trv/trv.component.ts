import { Component } from '@angular/core';

@Component({
  selector: 'app-trv',
  templateUrl: './trv.component.html',
  styleUrl: './trv.component.css'
})
export class TrvComponent {
  //click->textbox->message->display in the template
  messsage:string = "";

  name = "John"

  logMessage = (value:string) => {
    console.log(value)
    this.messsage = value;
  }
}
