import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrl: './child.component.css'
})
export class ChildComponent {
  @Input() parentData:string = ""

  @Output() childEvent = new EventEmitter()

  fireEvent(value:string){
    this.childEvent.emit(value)
  }
}
