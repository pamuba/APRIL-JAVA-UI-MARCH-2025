import { Component } from '@angular/core';

@Component({
  selector: 'app-classbinding',
  template: `
    <h1>Class Binding</h1>
    <h2 class="text-success">Class Binding</h2>
    <h2 [class]="successClass">Class Binding</h2>
    <h2 class="text-special" [class]="successClass">Class Binding</h2>
    <h2 [class.text-danger]="hasError">Class Binding</h2> 
    <h2 [ngClass]="tsClassObject">Class Binding</h2> 
  `,
  styles: [`
    
      .text-success{
        color:green;
      }
      .text-danger{
        color:red;
      }
      .text-special{
        font-style:italic;
      }

    `]
})
export class ClassbindingComponent {
  successClass = "text-success"
  hasError = false
  isSpecial = true
  tsClassObject = {
    "text-success":!this.hasError,
    "text-danger":this.hasError,
    "text-special":this.isSpecial
  } 
}
