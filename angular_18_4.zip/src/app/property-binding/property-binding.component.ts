import { Component } from '@angular/core';

@Component({
  selector: 'app-property-binding',
  template: `
    <h1>Property Binding</h1>
    <input [id]="myId" type="text" value="Angular"/>
    <br>
    <input id={{myId}} type="text" value="Angular"/>
    <br>
    <input [disabled]=false id={{myId}} type="text" value="Angular"/>
    <br>
    <input disabled="false" id={{myId}} type="text" value="Angular"/>
    <br>
    <input [disabled]="false" id={{myId}} type="text" value="Angular"/>
    <br>
    <input [disabled]=false id={{myId}} type="text" value="Angular"/>
  `,
  styles: []
})
export class PropertyBindingComponent {
  public myId = "myInput"
}
