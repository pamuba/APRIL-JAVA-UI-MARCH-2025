import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentListComponent } from './department-list/department-list.component';
import { EmlpoyeeListComponent } from './emlpoyee-list/emlpoyee-list.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { DepartmentdetailComponent } from './departmentdetail/departmentdetail.component';
const routes: Routes = [
  // {path:'', component : DepartmentListComponent},
  //localhost:4200
  {path:'', redirectTo:'/departments', pathMatch:'full'},
  
  {path:'departments', component :DepartmentListComponent},
  {path:'departments/:id', component :DepartmentdetailComponent},
  {path:'employees', component:EmlpoyeeListComponent},
  {path:'**', component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [DepartmentdetailComponent, DepartmentListComponent, EmlpoyeeListComponent]
