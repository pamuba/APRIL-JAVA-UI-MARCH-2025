import { Component } from '@angular/core';

@Component({
  selector: 'app-directives',
  template: `
    <!-- <h2 *ngIf="displayname; else elseBlock">
      ngIf Directive TRUE
    </h2>

    <ng-template #elseBlock>
     <h2>
      ngIf Directive FALSE
    </h2>
    </ng-template> -->
<!-- //////////////////////// -->
    <!-- <div *ngIf="displayname; 
    then thenBlock; else elseBlock">
      <h2>THE DIV WILL NEVER DISPLAY</h2>
    </div>

    <ng-template #thenBlock>
      <h2>Then Block</h2>
    </ng-template>

    <ng-template #elseBlock>
      <h2>Else Block</h2>
    </ng-template> -->
    <!-- /////////////////////////////// -->

    <!-- <div [ngSwitch]="color">
      <div [style.color]="color" *ngSwitchCase="'red'">RED</div>
      <div [style.color]="color" *ngSwitchCase="'blue'">BLUE</div>
      <div [style.color]="color" *ngSwitchCase="'yellow'">YELLOW</div>
      <div *ngSwitchDefault>Default Case</div>
    </div> -->

    <!-- ///////////////////////////////// -->


  <div *ngFor="let clr of colors;
   index as i first as f last as l
   odd as o">
    <h2 [style.color]="clr">{{o}} {{i}}.{{clr}}</h2>
  </div>

  `,
  styles:[]
})
export class DirectivesComponent {
 displayname = true;
 color:string = "green"
 colors = ["red", "blue", "green", "yellow"]
}
