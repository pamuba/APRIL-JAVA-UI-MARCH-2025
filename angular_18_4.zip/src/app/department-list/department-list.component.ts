import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrl: './department-list.component.css'
})
export class DepartmentListComponent {

  constructor(private router:Router){}

  departments = [
    {"id":1, "name": "Angular"},
    {"id":2, "name": "NodeJS"},
    {"id":3, "name": "Bootstrap"},
    {"id":4, "name": "MongoDB"},
    {"id":5, "name": "ReactJS"},
  ]
  onSelect(dept:any){
    console.log(dept.id)
    this.router.navigate(['/departments', dept.id]);
  }
}
