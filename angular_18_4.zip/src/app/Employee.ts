export interface Employee{
    id:Number,
    name:string,
    age:Number
}