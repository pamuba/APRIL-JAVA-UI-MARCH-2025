import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello/hello.component';
import { PropertyBindingComponent } from './property-binding/property-binding.component';
import { ClassbindingComponent } from './classbinding/classbinding.component';
import { TestComponent } from './test/test.component';
import { TrvComponent } from './trv/trv.component';
import { FormsModule } from '@angular/forms';
import { DirectivesComponent } from './directives/directives.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { PipesComponent } from './pipes/pipes.component';
import { EmlpoyeeListComponent } from './emlpoyee-list/emlpoyee-list.component';
import { EmlpoyeeDetailComponent } from './emlpoyee-detail/emlpoyee-detail.component';
import { HttpClientModule } from '@angular/common/http';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';


@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    PropertyBindingComponent,
    ClassbindingComponent,
    TestComponent,
    TrvComponent,
    DirectivesComponent,
    ParentComponent,
    ChildComponent,
    PipesComponent,
    EmlpoyeeDetailComponent,
    routingComponents,
    PagenotfoundComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
