import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';

@Component({
  selector: 'emlpoyee-list',
  templateUrl: './emlpoyee-list.component.html',
  styleUrl: './emlpoyee-list.component.css'
})
export class EmlpoyeeListComponent {

  constructor(private empService:EmployeeService){}

  employees:Employee[] = []

  ngOnInit(){
    this.empService.getEmployees()
      .subscribe(data => this.employees = data);
  }
}
