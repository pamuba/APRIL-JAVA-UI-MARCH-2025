import './App.css';
import ClassCounter from './components/ClassCounter';
import HookCounter from './components/HookCounter';
import HookCounterTwo from './components/HookCounterTwo';
import ClassCounterOne from './components/ClassCounterOne';
import HookCounterOne from './components/HookCounterOne';
import ClassMouse from './components/ClassMouse';
import HookMouse from './components/HookMouse';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <ClassCounter/>
        <HookCounter/> */}
        {/* <HookCounterTwo/> */}
        {/* <ClassCounterOne></ClassCounterOne> */}
        {/* <HookCounterOne></HookCounterOne> */}
        {/* <ClassMouse></ClassMouse> */}
        <HookMouse></HookMouse>
      </header>
    </div>
  );
}

export default App;
