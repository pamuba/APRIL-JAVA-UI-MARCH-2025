// import React, { Component } from 'react'

// export class ClassMouse extends Component {
//  constructor(props){
//     super(props)
//     this.state = {
//         x:0,
//         y:0
//     }
//  }
//   logMousePosition = (e) => {
//     console.log('logMousePosition() is called')
//     this.setState({x:e.clientX, y:e.clientY})
//   }
//   componentDidMount(){
//     window.addEventListener('mousemove', this.logMousePosition);
//   }
//   componentWillUnmount(){
//     window.removeEventListener('mousemove', this.logMousePosition);
//   }
//   render() {
//     return (
//       <div>
//         X - {this.state.x} Y - {this.state.y}
//       </div>
//     )
//   }
// }

// export default ClassMouse

import React, { useEffect, useState } from 'react'

function ClassMouse() {
  const [x, setX] = useState(0)
  const [y, setY] = useState(0)

  const logMousePosition = (e) => {
    console.log('logMousePosition() called')
    setX(e.clientX)
    setY(e.clientY)
  }
  //componentDidMount
  useEffect(()=>{
    window.addEventListener('mousemove', logMousePosition)

    //componentWillUnmount
    return () => {
        console.log('removeEventListener')
        window.removeEventListener('mousemove', logMousePosition);
    }
  },[])
  return (
    <div>
        Hooks X - {x} Y - {y}
    </div>
  )
}

export default ClassMouse