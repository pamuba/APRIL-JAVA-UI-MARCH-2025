import React, { useState } from 'react'
import ClassMouse from './ClassMouse'

function HookMouse() {
  const [display, setDisplay] = useState(true)
  return (
    <div>
        <button onClick={()=> setDisplay(!display)}>Toggle Display</button>
        { display && <ClassMouse />}
    </div>
  )
}

export default HookMouse