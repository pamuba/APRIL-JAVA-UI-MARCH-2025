const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
const Video = require('../../models/Video')

mongoose.connect('mongodb://localhost:27017/VideoLib')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Connection error', err));
  

  
//localhost:4000/api/videos
//Get all Videos
router.get('/videos',async function(req, res){
    console.log("Get request for all Videos")
    const results = await Video.find({});
    console.log(results);

    Video.find({})
    .exec()
    .then(videos => {console.log(videos); return res.json(videos)})
    .catch(error => res.status(500).json({ error: 
        'Error fetching data' }))
})

//get a video by id
router.get('/videos/:id', function(req, res){
  console.log("Get request for a Video")
  Video.findById(req.params.id)
      .exec()
      .then(video => res.json(video))
      .catch(error => res.status(500).json({ error: 
        'Error fetching data' }))
})


//post a video
//localhost:4000/api/video
router.post('/video',function(req, res){
  console.log("Post a video");

  let newVideo = new Video();

  newVideo.title = req.body.title;
  newVideo.url = req.body.url;
  newVideo.description = req.body.description;

  newVideo.save()
  .then(insertedVideo => res.json(insertedVideo))
  .catch(console.error('Error saving the video'))
})


//Updating a video
router.put('/video/:id', function(req, res){
  console.log('Updating a Video')
  Video.findByIdAndUpdate(req.params.id,
      {
          $set:{title: req.body.title, url: req.body.url, description: req.body.description}
      },{
          new:true
      })
      .then(updatedVideo => res.json(updatedVideo))
      .catch(console.error('Error saving the video'))
});

//Delete a document
router.delete('/video/:id', function(req, res){
  console.log('Deleting a Video')
  Video.findByIdAndDelete(req.params.id)
  .then( deletedVideo =>res.json(deletedVideo) )
  .catch(console.error('Error deleting a video'))
});

module.exports = router 