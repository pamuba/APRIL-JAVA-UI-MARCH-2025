import { Component } from '@angular/core';
import { Video } from '../video';
import { VideoService } from '../video.service';

@Component({
  selector: 'app-video-center',
  templateUrl: './video-center.component.html',
  styleUrl: './video-center.component.css'
})
export class VideoCenterComponent {

  constructor(private _videoService:VideoService){}
  selectedVideo!:Video;
  videos: Video[]= []
  hidenewVideo:boolean = true

  newVideo(){
    this.hidenewVideo = false
  }

  ngOnInit(){
    this._videoService.getVideos()
      .subscribe(resVideoData => this.videos = resVideoData)
  }

  onSelectVideo(video:Video){
    this.selectedVideo = video;
    this.hidenewVideo = true;
    console.log(this.selectedVideo)
  }

  onSubmitAddVideo(video:Video){
    console.log(video)
     this._videoService.addVideo(video)
        .subscribe(resNewVideo => {
          this.videos.push(resNewVideo)
          this.hidenewVideo = true
          this.selectedVideo = resNewVideo
        })
  }

  onUpdateVideoEvent(video:Video){
    this._videoService.updateVideo(video)
        .subscribe(resUpdatedVideo => video = resUpdatedVideo)
    this.selectedVideo = video;
  }
  onDeleteVideoEvent(video:Video){
      this._videoService.deleteVideo(video)
      .subscribe(resDeletedVideo => 
        this.videos.filter(video => video !== resDeletedVideo))
    this.selectedVideo = this.videos[0]
  }
}
