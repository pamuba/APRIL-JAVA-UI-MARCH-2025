import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Video } from '../video';

@Component({
  selector: 'video-detail',
  templateUrl: './video-detail.component.html',
  styleUrl: './video-detail.component.css'
})
export class VideoDetailComponent {
 editTitle:boolean = false;
 @Input() video!:Video;
 @Output() updateVideoEvent = new EventEmitter();
 @Output() deleteVideoEvent = new EventEmitter();

 onTitleClick(){
  this.editTitle = true;
 }

 ngOnChanges(){
  this.editTitle = false;
 }
 updateVideo(){
  this.updateVideoEvent.emit(this.video);
  this.editTitle = false;
 }
 deleteVideo(){
  this.deleteVideoEvent.emit(this.video);
 }

}
