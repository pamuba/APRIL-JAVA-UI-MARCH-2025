export class Video {
    _id!:string;
    title!:string;
    url!:string;
    description!:string
}
