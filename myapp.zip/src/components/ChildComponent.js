import React from 'react'

function ChildComponent(props) {
  return (
    <div>
        <input type='text'></input>
        <hr></hr>
        <button onClick={()=>props.greetHandler('data from child')}>Greet Parent</button>
    </div>
  )
}

export default ChildComponent