import React, { Component } from 'react'

export class GreetClass extends Component {
  render() {
    const {name, character, children} = this.props
    //const {name, character, children} = this.state
    return (
      <>
        <h1>
          Hello {name} aka {character}
        </h1>
        {children}
      </>
    )
  }
}

export default GreetClass