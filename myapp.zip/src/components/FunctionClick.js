import React from 'react'

export default function FunctionClick() {
  function clickHandler(){
    console.log('Clicked')
  }
  return (
    <>
        <button onClick={clickHandler}>Click</button>
    </>
  )
}
