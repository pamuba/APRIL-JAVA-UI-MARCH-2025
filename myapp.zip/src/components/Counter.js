import React, { Component } from 'react'

export class Counter extends Component {
    constructor(props){
        super(props)
        this.state = {
            count:0,
            prev:0
        }
    }
    increment(){
        //async
        // this.setState({
        //     count:this.state.count + 1
        // }, ()=>{ console.log('CURRENT:'+this.state.count)})
        // console.log('OLD:'+this.state.count)

        this.setState((prevState)=>({
            count:prevState.count + 1,
            prev:prevState.count
        }), ()=>{ console.log('CURRENT:'+this.state.count+" "+'PREV:'+this.state.prev)})
    }
    incrementbyFive(){
        this.increment();
        this.increment();
        this.increment();
        this.increment();
        this.increment();
    }
    render() {
        const {count} = this.state
        return (
            <div>
                <h3>Count - {count}</h3>
                <button onClick={()=>this.increment()}>Increment</button>
                <button onClick={()=>this.incrementbyFive()}>IncrementByFive</button>

            </div>
        )
    }
}

export default Counter