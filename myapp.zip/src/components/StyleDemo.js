import React from 'react'
import './myStyles.css'

function StyleDemo(props) {
 let className = props.primary ? 'primary' : 'secondary'
  return (
    <h1 className={`${className} font-xl`}>Stylesheet</h1>
  )
}

export default StyleDemo