import React, { Component } from 'react'
import ComponentF from './ComponentF'
import UserContext from './UserContext'

export class ComponentD extends Component {
  render() {
    return (
      <div> 
        Component D - {this.context}
        <ComponentF />
      </div>
    )
  }
}

ComponentD.contextType = UserContext

export default ComponentD