import React from 'react'

function ErrorBoundary({heroName}) {
  if(heroName === 'Joker'){
    throw new Error('Not a HERO')
  }
  return (
    <div>
        Name: {heroName}
    </div>
  )
}

export default ErrorBoundary