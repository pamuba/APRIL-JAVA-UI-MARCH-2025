import React from 'react'

// export default function Greet() {
//   return (
//     <div>Greet</div>
//   )
// }

const Greet = ({name, character, children}) => {
    return (
        <>
            <h1>Hello {name} aka {character}</h1>
            {children}
        </>
    )
}

export default Greet