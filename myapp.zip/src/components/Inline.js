import React from 'react'

const heading = {
    fontSize:'80px',
    color:'blue'
}

function Inline() {
  return (
    <>
        <div className='error'>Inline</div>
        <div style={heading}>Inline</div>
    </>
  )
}

export default Inline