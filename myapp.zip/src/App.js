import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet';
import GreetClass from './components/GreetClass';
import Hello from './components/Hello';
import Message from './components/Message';
import Counter from './components/Counter';
import FunctionClick from './components/FunctionClick';
import ClassClick from './components/ClassClick';
import EventBind from './components/EventBind';
import ParentComponent from './components/ParentComponent';
import ConditionalRendering from './components/ConditionalRendering';
import StyleDemo from './components/StyleDemo';
import Inline from './components/Inline';
import './components/appStyles.css';
import styles from './components/appStyles.module.css'
import PureComp from './components/PureComp';
import PrentComponent from './components/PrentComponent';
import ErrorBoundary from './components/ErrorBoundary';
import ErrorBoundary1 from './components/ErrorBoundary1';
import ComponentC from './components/ComponentC';
import { UserProvider } from './components/UserContext'
//JSX
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1 className='error'>Error</h1>
        <h1 className={styles.success}>Super Success</h1>
       {/* <Greet name="Bruce" character="Batman">
        <h3>Children Props</h3>
       </Greet>
       <Greet name="Clark" character="Superman"/>
       <Greet name="Diana" character="Wonder Woman"/> */}

       {/* <GreetClass name="Bruce" character="Batman">
       <h3>Children Props</h3>
       </GreetClass>
       <GreetClass name="Clark" character="Superman"/>
       <GreetClass name="Diana" character="Woder Woman"/> */}

       {/* <Message></Message> */}
       {/* <Counter></Counter> */}

       {/* <FunctionClick></FunctionClick> */}

      {/* <ClassClick></ClassClick> */}
      
      {/* <EventBind></EventBind> */}

      {/* <ParentComponent></ParentComponent> */}

      {/* <ConditionalRendering></ConditionalRendering> */}

     
      {/* <StyleDemo primary={true}></StyleDemo> */}
      
       {/* <Inline></Inline> */}
       
        {/* <PrentComponent></PrentComponent> */}

        {/* <ErrorBoundary1>
          <ErrorBoundary heroName="Superman" ></ErrorBoundary>
        </ErrorBoundary1>
        
        <ErrorBoundary1>
          <ErrorBoundary heroName="Batman" ></ErrorBoundary>
        </ErrorBoundary1>
        
        <ErrorBoundary1>
          <ErrorBoundary heroName="Joker" ></ErrorBoundary>
        </ErrorBoundary1> */}

          <UserProvider value='John Snow'>
             <ComponentC />
          </UserProvider>
        

      </header>
    </div>
  );
}

export default App;
